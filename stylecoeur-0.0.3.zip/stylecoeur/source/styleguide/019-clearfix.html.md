---
title: Clearfix
type: styleguide
layout: layout-styleguide
name: icons
section: basics
source: ../
---

<main markdown="1">
  
## Clearfix

Clearfix can sometimes be useful 'fixing' layouts that are positioned.

Just add `.clearfix` to an element for clearfix.

Easy Peazy

</main>