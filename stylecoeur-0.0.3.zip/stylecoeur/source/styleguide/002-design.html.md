---
title: Design
type: styleguide
layout: layout-styleguide
name: design
section: about
source: ../
---

<main markdown="1">

# Design

Evoke a sense of productivity with a side of trust, safety, and playfulness. Playful language and design will set the product apart from the likes of AWS and even some of the other companies we looked at. We have to avoid crossing the line to feeling too much like a kids toy or a game.


## App Design

## Process

Client onboarding process
Design Process

## Testing

TDD / Test Driven Development / Test-Driven Design

</main>


