---
title: Chat & Chatbot
type: styleguide
layout: layout-styleguide
name: chat
section: components
status: --draft
source: ../
---

<main markdown="1">

## Chat & Chatbot

Chat bots and "chat interfaces" are gettin a lot more popular. Sometimes they look like iMessage, sometimes they look like other things.

This section mainly exists to **define** what the aspects are for a chat interface and for a chatbot interface, and what those differences are.

Inspiration / Guidance:

- Quartz App
- iMessage
- Drift.com chatbox


</main>