---
title: User Stories
type: styleguide
layout: layout-styleguide
name: userStories
section: about
status: --draft
source: ../
---

<main markdown="1">

DESIGN NEEDS GO INTO THE DESIGN SySTEM PAGE


# Design

Talk about reusable user stories here, design, implementation, note taking, molecular design and componentization

future of style coeur:

- create partials for BA / info design
- reuse user stories
- partials, linked back to code, to react components
- linked to test-driven design and development