---
title: Transitions
type: styleguide
layout: layout-styleguide
name: transitions
section: scriptcoeur
status: --draft
source: ../
---

<main class="_styleguide" markdown="1">


## Transitions w/ BarbaJS

Placeholder




</main>



