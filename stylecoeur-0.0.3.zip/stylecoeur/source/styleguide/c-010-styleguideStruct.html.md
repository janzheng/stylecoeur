---
title: Styleguide Structure
type: styleguide
layout: layout-styleguide
name: styleguideStructure
section: middleman
status: --draft
source: ../
---

<main markdown="1">

## Styleguide Structure

Numerical naming system

How the indexer works